Name: Marissa Connell
Date: 01/09/2023
Class: CYCS1200 - Programming in C
Semester: Spring 2023

Environment:
    - Operating System: macOS
    - Emulator: MinGW
    - Text Editor: VSCode
    - Compiler: gcc

Resources:
    - Tutorials Point: https://www.tutorialspoint.com/cprogramming/index.htm
    - Visual Studio Code: https://code.visualstudio.com/docs/cpp/config-clang-mac
