#include <stdio.h>

/* main: generate some simple output */

int main(void)
{
    printf("Hello, World.\n");
    return 0;
}