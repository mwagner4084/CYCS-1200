#include <stdio.h>
#include <stdlib.h>

int main (void)
{
  printf ("%i\n", 17 * 3);
  
  return (EXIT_SUCCESS);
}