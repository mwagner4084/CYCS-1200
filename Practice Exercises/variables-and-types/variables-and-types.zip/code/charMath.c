#include <stdio.h>
#include <stdlib.h>

int main (void)
{
  char letter;
  letter = 'a' + 1;
  printf ("%c\n", letter);
  
  return (EXIT_SUCCESS);
}