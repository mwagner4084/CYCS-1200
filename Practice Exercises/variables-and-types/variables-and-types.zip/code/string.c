#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    char first[] = "Hello, ";
    char second[] = "world.";
  
    printf("%s", first);
  
    return(EXIT_SUCCESS);
}