#include <stdio.h>
#include <stdlib.h>

char first_letter;
int hour, minute;

int main (void)
{
  first_letter = 'a'; /* give first_letter the value ’a’ */
  hour = 11; /* assign the value 11 to hour */
  minute = 59; /* set minute to 59 */
  return (EXIT_SUCCESS);
}