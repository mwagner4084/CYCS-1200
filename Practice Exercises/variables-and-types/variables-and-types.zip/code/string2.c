#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    char fruit[] = "banana";
    char letter = fruit[1];
    printf ("%c\n", letter);

    return(EXIT_SUCCESS);
}