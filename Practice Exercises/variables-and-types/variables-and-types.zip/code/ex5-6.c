#include <stdio.h>
#include <stdlib.h>
#include <math.h>

double SumSquares(double a, double b)
{
   return pow(a, 2.0) + pow(b, 2.0);
}



int main(void)
{
    double dist = Distance(0.0, 0.0, 3.0, 4.0);
  
    return(EXIT_SUCCESS);
}