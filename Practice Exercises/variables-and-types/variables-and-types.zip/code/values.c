#include <stdio.h>
#include <stdlib.h>

/* main: generate some simple output */

int main (void)
{
    printf("%i\n", 17);
    return (EXIT_SUCCESS);
}