#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    
    int x = 8;
  
    if (x > 0) 
    {
      if (x < 10) 
      {
          printf ("x is a positive single digit.\n");
      }
    }

    return(EXIT_SUCCESS);
}