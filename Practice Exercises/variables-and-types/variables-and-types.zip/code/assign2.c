#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int fred = 5;
    printf ("%i", fred);
  
    fred = 7;
    printf ("%i", fred);
  
    return(EXIT_SUCCESS);
}