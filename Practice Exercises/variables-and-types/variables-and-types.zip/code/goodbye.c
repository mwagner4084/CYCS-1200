#include <stdio.h>
#include <stdlib.h>

/* main: generate some simple output */

int main (void)
{
    printf ("Goodbye, "); /* output one line */
    printf ("cruel world!\n"); /* output another line */
    return (EXIT_SUCCESS);
}