#!/bin/bash

$1 $2 $3 $4 -lm
$5